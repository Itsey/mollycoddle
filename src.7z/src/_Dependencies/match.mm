﻿#PS Dummy
**/nd*.txt
