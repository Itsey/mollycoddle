﻿#PS Dummy
Write-Host "Hello World from inside powershell"

foreach($a in $args ) {
	Write-Host $a
}

Write-Host "Complete."