﻿namespace mollycoddle {

    public abstract class CheckerBase : ICheckStuff {
    }
}