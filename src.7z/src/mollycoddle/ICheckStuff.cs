﻿namespace mollycoddle {

    public interface ICheckStuff {
    }
}